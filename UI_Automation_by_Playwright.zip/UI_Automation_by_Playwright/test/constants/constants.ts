
export const GLOBAL_TIME_OUT = 30000;
export const SHORT_TIME_OUT = 5000;
export const MEDIUM_TIME_OUT = 10000;
export const LONG_TIME_OUT = 20000;
export const VERY_LONG_TIME_OUT = 60000;
export const POLLING_INTERVAL = 250;
import { Locator, Page } from "@playwright/test";
import ENV from "../utils/env";

//Customer Details

//Module Names

//Customer Type

//Product Type

//Sales Type

//Payment Type
